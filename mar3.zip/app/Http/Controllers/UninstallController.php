<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Shopify\Auth\OAuth;
use Shopify\Webhooks\Topics;

class UninstallController extends Controller
{
   
}
